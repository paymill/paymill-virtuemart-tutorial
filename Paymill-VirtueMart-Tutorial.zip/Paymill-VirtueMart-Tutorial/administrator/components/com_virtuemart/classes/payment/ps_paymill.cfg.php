<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('PAYMILL_PRIVATE_KEY', '');
define ('PAYMILL_PUBLIC_KEY', '');
?>